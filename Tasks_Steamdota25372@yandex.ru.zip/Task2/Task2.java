/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Potemkin
 */
public class Task2 {

    /**
     * @param args the command line arguments
     */
    //static MainFrame mainFrame;        
    public static void main(String[] args) {
        // TODO code application logic here
        int testCount=readTestCount(10);
        Scanner in=new Scanner(System.in);
        for(int i=0;i<testCount;i++){  
            int citiesCount=readCitiesCount(10000);
            //arrOfCities contains the cities. The city includes his index in the matrix of distances, and his name
            City[] arrOfCities=new City[citiesCount];       
            //The matrix of distances. The intersection of the i-th row and j-th column contains
            //the distance between the relevant cities.
            int[][] distBtvCities=readDistBtvCities(arrOfCities);      
            //arrOfPathsToFind contains the indexes of cities between them we must find a better way.
            Path[] arrOfPathsToFind=readArrOfPathsToFind(100,arrOfCities);                                        
            System.out.println("Output");
            for(int currPath=0;currPath<arrOfPathsToFind.length;currPath++){                
                int bestCost=findThePath(0,Integer.MAX_VALUE,distBtvCities,new ArrayList<Integer>(),arrOfPathsToFind[currPath].getSrcIndex(),arrOfPathsToFind[currPath].getDstIndex());
                System.out.println(bestCost);
            }
            System.out.println();
        }        
        
    }
    //The recursive method that searches the minimum cost way.
    //Bypassing cities starting from "currIndex" and implemented bypassing the graph in depth. 
    //currIndex - index of the current city on the current recursion step.
    static int findThePath(int currCost, int bestCost, int[][] distBtvCities,ArrayList<Integer> arrOfVisited, int currIndex, int dstIndex){        
        //array of the visited cities at this recursion step.
        ArrayList<Integer> currStateOfArrOfVisited=new ArrayList();
        for(int i=0;i<arrOfVisited.size();i++){
            currStateOfArrOfVisited.add(arrOfVisited.get(i));
        }
        //cycle through all the cities
        for(int i=0;i<distBtvCities.length;i++){  
            //if the distance between cities != 0 then...
            if(distBtvCities[i][currIndex]!=0){
                //if i-th city is a city of destination then...
                if(i==dstIndex){                    
                    currCost+=distBtvCities[i][currIndex];                    
                    if(currCost<bestCost){
                        bestCost=currCost;                        
                    }
                    currCost-=distBtvCities[i][currIndex];                    
                }
                //check if i=th city contains in the list of visited.
                boolean wasVisited=false;
                for(int j=0;j<currStateOfArrOfVisited.size();j++){
                    if(currStateOfArrOfVisited.get(j)==i||i==dstIndex){
                       wasVisited=true;
                       break;
                    }
                }
                //if i-th city not contains then we note that city as visited and go to the next step of recursion
                if(!wasVisited){
                    currCost+=distBtvCities[i][currIndex];                    
                    arrOfVisited.add(currIndex);                    
                    bestCost=findThePath(currCost,bestCost,distBtvCities,arrOfVisited,i,dstIndex);
                    currCost-=distBtvCities[i][currIndex];                    
                    arrOfVisited=new ArrayList();
                    for(int j=0;j<currStateOfArrOfVisited.size();j++){
                        arrOfVisited.add(currStateOfArrOfVisited.get(j));
                    }                    
                }
            }
        }
        return bestCost;
    }
    
    static Path[] readArrOfPathsToFind(int maxFindingPathsCount, City[] arrOfCities){        
        int findingPathsCount=maxFindingPathsCount+1;
        Scanner in = new Scanner(System.in);
        while(findingPathsCount>maxFindingPathsCount){
            System.out.println("the number of paths to find <= 100: ");
            findingPathsCount=in.nextInt();            
        }   
        in.nextLine();
        Path[] arrOfPathsToFind=new Path[findingPathsCount];
        String strSrcDst;
        for(int i=0;i<findingPathsCount;i++){
            //System.out.println(i+" path: ");            
            strSrcDst=in.nextLine();            
            int indexOfSpace=strSrcDst.indexOf(" ");
            arrOfPathsToFind[i]=new Path(strSrcDst.substring(0, indexOfSpace), strSrcDst.substring(indexOfSpace+1, strSrcDst.length()), arrOfCities);
            //System.out.println(arrOfPathsToFind[i].getSrc()+"         "+arrOfPathsToFind[i].getDst());
        }   
        return arrOfPathsToFind;
    }
    //read the matrix of distances between cities
    static int[][] readDistBtvCities(City[] arrOfCities){
        int[][] distBtvCities=new int[arrOfCities.length][arrOfCities.length];
        Scanner in = new Scanner(System.in); 
        String cityName;
        int neighboursCount; 
        int neighbourIndex;
        for(int i=0;i<arrOfCities.length;i++){
            System.out.println("city name: ");
            //read the line inputed by user from keyboard.
            cityName=in.nextLine();            
            if(cityName.isEmpty())cityName=in.nextLine();
            //create an object of City (index of city, name of city) and save this obj to an array arrOfCities.
            arrOfCities[i]=new City(i,cityName);            
            System.out.println("the number of neighbours of city "+arrOfCities[i].getName()+": ");
            neighboursCount=in.nextInt();
            for(int j=0;j<neighboursCount;j++){
                System.out.println("index of a city connected to "+arrOfCities[i].getName()+"(the index of the first city is 1) and  the transportation cost");                
                String str=in.nextLine();                
                if(str.isEmpty())str=in.nextLine();       
                //str containt 2 values like: "1 2". 
                //It need to allocate these values and write in 2 variables of type int.
                int indexOfSpace=str.indexOf(" ");
                //allocate and write 1-st value.
                //the index of the first city is 1 so we need decrease value by 1.
                neighbourIndex=Integer.parseInt(str.substring(0, indexOfSpace))-1;                
                //allocate and write 2-nd value.
                distBtvCities[i][neighbourIndex]=Integer.parseInt(str.substring(indexOfSpace+1, str.length()));
            }            
        }
        return distBtvCities;
    }        
    //read the cities count.
    static int readCitiesCount(int maxCitiesCount){
        int citiesCount=maxCitiesCount+1;  
        Scanner in = new Scanner(System.in);                
        while(citiesCount>maxCitiesCount){
            System.out.println("the number of cities <= 10000: ");
            citiesCount=in.nextInt();
        }
        return citiesCount;
    }
    //read test count.
    static int readTestCount(int maxTestCoun){
        Scanner in = new Scanner(System.in);
        int testCount=maxTestCoun+1;
        while(testCount>maxTestCoun){
            System.out.println("the number of tests <= 10: ");
            testCount=in.nextInt();
        }        
        //in.close();
        return testCount;
    }
}
class City{
    private int index; //index of city
    private String name; //name of city
    public City(int index, String name){
        this.index=index;
        this.name=name;               
    }
    public int getIndex(){
        return index;
    }
    public String getName(){
        return name;
    }
}
class Path{
    private int srcIndex;
    private int dstIndex;    
    public Path(String src, String dst, City[] arrOfCities){
        //get city index by name
        for(int i=0;i<arrOfCities.length;i++){
            if(src.equals(arrOfCities[i].getName())){
                srcIndex=i;
            }
            if(dst.equals(arrOfCities[i].getName())){                
               dstIndex=i;
            }
        }     
    }
    public int getSrcIndex(){
        return srcIndex;
    }
    public int getDstIndex(){
        return dstIndex;
    }
}