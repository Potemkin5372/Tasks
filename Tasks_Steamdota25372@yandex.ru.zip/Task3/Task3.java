/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task3;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Potemkin
 */
public class Task3 {

    /**
     * @param args the command line arguments
     */
    static MainFrame mainFrame;
    public static void main(String[] args) {
        // TODO code application logic here                
        mainFrame=new MainFrame();
        mainFrame.setTitle("Task3");
        //setting coordinates of frame location.
        mainFrame.setLocation(100, 0);
        //when closing mainFrame the application quits
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame becomes visible
        mainFrame.setVisible(true);
        //setting size of frame based on the size of his components
        mainFrame.pack();
    }
    //metod return factorial of "number" in string format.
    static String getFactorialAsString(int number){
        //initial value of the factorial is 1.
        BigInteger factorialValue = BigInteger.ONE;
        //search factorial 
        for (int i = 1; i <= number; i++){
            factorialValue = factorialValue.multiply(BigInteger.valueOf(i));            
        }        
        return factorialValue.toString();
    }
    //metod get the factorial as string and converts each digit in this string to the integer type;
    //finds the sum of all digits; return result.
    static int calculateSumOfDigits(String str){
        int answer=0;
        for(int i=0;i<=str.length()-1;i++){
            answer+=Integer.parseInt(str.substring(i,i+1));            
        }
        return answer;
    }
}
class MainFrame extends JFrame{
    //main panel containing all other components. All components in this panel placed in a vertical.
        private JPanel mainPanel;
        //panel for data input components. All components in this panel placed in a horizontal.
        private JPanel inputPanel;
        //textField for number inputing.
        private JTextField inputNumber;
        private JButton btnStartSearching;        
        //message to the user about number inputing.
        private JLabel lInfo;
        private JLabel lAnswer;
        public MainFrame(){            
            mainPanel=new JPanel();
            //set the layout manager of vertical component placement.
            mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
            
            inputPanel=new JPanel();
            //set the layout manager of horizontal component placement.
            inputPanel.setLayout(new BoxLayout(inputPanel,BoxLayout.X_AXIS));
            
            lInfo=new JLabel();
            lInfo.setText("Enter the number:");
            
            lAnswer=new JLabel("Answer:");
                                      
            inputNumber=new JTextField();
            //set preferred dimension of inputNumber component.
            inputNumber.setPreferredSize(new Dimension(100,20));        
            
            btnStartSearching=new JButton("Search!");
            //adding the action listener to the button.
            btnStartSearching.addActionListener(new ActionListener(){                
                public void actionPerformed(ActionEvent e) {
                    btnStartSearchingEvt();
                }                
            });
            
            //adding components to inputPanel
            inputPanel.add(lInfo);
            inputPanel.add(Box.createRigidArea(new Dimension(20,0)));
            inputPanel.add(inputNumber);
            inputPanel.add(Box.createRigidArea(new Dimension(20,0)));
            inputPanel.add(btnStartSearching);
            
            //adding inputPanel to mainPanel
            mainPanel.add(inputPanel);            
            mainPanel.add(lAnswer);
            //adding mainPanel to the frame.
            this.add(mainPanel);
        }
        private void btnStartSearchingEvt(){             
            //get inputed Number converted from string to int.
            int number=Integer.parseInt(inputNumber.getText());            
            setAnswer(Task3.calculateSumOfDigits(Task3.getFactorialAsString(number)));
        }
        public void setAnswer(long answer){
            lAnswer.setText("Answer: "+answer);
        }       
}