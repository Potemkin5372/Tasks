/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task1;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Potemkin
 */
public class Task1 {

    /**
     * @param args the command line arguments
     */
    //static char[] charBuf;
    
    static MainFrame mainFrame;
    //the number of correct bracket expressions containing N opening and N closing braces
    static long slnsCount=0;
    public static void main(String[] args) {
        // TODO code application logic here        
        mainFrame=new MainFrame();        
        mainFrame.setTitle("Task1");        
        //setting frame size and the coordinates of frame location.
        mainFrame.setBounds(100, 0, 300, 200);
        //when closing mainFrame the application quits
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame becomes visible
        mainFrame.setVisible(true);
        
    }
    //every solution is a bracket expression, that will be recorded into a string.
    //Before generating every solution formed the StringBuffer like this: ")   )   )" and returned 
    //by method initStrForSlns().
    //The number of brackets in StringBuffer = N. 
    //The number of spaces between the brackets StringBuffer = N.
    static StringBuffer initStrForSlns(int bktCount){
        StringBuffer str=new StringBuffer();
        for(int i=0;i<bktCount;i++){
            str.append(new char[bktCount]);
            str.append(")");
        } 
        return str;
    }
    //This recursive method that searches solutions.
    //He enumerates all possible options of the correct brackets placement. For example:
    //1) ((()   )   );
    //2) (( )  ()   );
    //3) (( )   )  ();
    //4) (  ) (()   ); etc... 
    static void searchSlns(int bktCount, int prevBktOffset, StringBuffer str, int currBktIndex){               
        StringBuffer prevStr=new StringBuffer(str);        
        for(int currBktOffset=prevBktOffset;currBktOffset<=currBktIndex;currBktOffset++){              
            str.replace(currBktIndex+(currBktOffset*bktCount),currBktIndex+(currBktOffset*bktCount)+1, "(");                        
            if(currBktIndex+1<bktCount){
               searchSlns(bktCount,currBktOffset,str, currBktIndex+1);
            }else{    
                //removing all spaces from the StringBuffer.
                for(int i=0;i<str.length();i++){                    
                    if(str.charAt(i)==' '){
                        str.deleteCharAt(i);                        
                        i--;
                    }
                }                          
                mainFrame.addSln(str.toString());
                slnsCount++;                
            }
            str=new StringBuffer(prevStr);                       
        }        
    }    
}
class MainFrame extends JFrame{
        //main panel containing all other components. All components in this panel placed in a vertical.
        private JPanel mainPanel;
        //panel for data input components. All components in this panel placed in a horizontal.
        private JPanel inputPanel;
        //textField for brackets count inputing.
        private JTextField inputBktCount;        
        private JButton btnStartSearching;
        //textArea that displays all solutions.
        private JTextArea txtSlns;
        //message to the user about inputing of brackets count.
        private JLabel lInfo;        
        private JLabel lAnswer;
        public MainFrame(){            
            mainPanel=new JPanel();
            
            //set the layout manager of vertical component placement.
            mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
            
            inputPanel=new JPanel();
            //set the layout manager of horizontal component placement.
            inputPanel.setLayout(new BoxLayout(inputPanel,BoxLayout.X_AXIS));
            
            lInfo=new JLabel();
            lInfo.setText("Enter brackets count:");
            
            lAnswer=new JLabel("Answer:");
                        
            txtSlns=new JTextArea();    
            
            inputBktCount=new JTextField();
            //set immutable dimensions of inputBktCount component.
            inputBktCount.setPreferredSize(new Dimension(30,20));
            inputBktCount.setMinimumSize(new Dimension(30,20));
            inputBktCount.setMaximumSize(new Dimension(30,20));            
            
            btnStartSearching=new JButton("Search!");
            //adding the action listener to the button.
            btnStartSearching.addActionListener(new ActionListener(){                
                public void actionPerformed(ActionEvent e) {
                    btnStartSearchingEvt();
                }                
            });
            
            //adding components to inputPanel
            inputPanel.add(lInfo);
            inputPanel.add(inputBktCount);
            inputPanel.add(btnStartSearching);
            
            //adding inputPanel to mainPanel
            mainPanel.add(inputPanel);
            //adding the possibility to scroll field txtSlns.
            mainPanel.add(new JScrollPane(txtSlns));
            mainPanel.add(lAnswer);
            //adding mainPanel to the frame.
            this.add(mainPanel);
        }
        //all actions by pressing a button btnStartSearching
        private void btnStartSearchingEvt(){                    
            txtSlns.setText("");
            Task1.slnsCount=0;  
            //get inputed brackets count converted from string to int.
            int bktCount=Integer.parseInt(inputBktCount.getText());
            Task1.searchSlns(bktCount, 0, Task1.initStrForSlns(bktCount), 0); 
            setAnswer(Task1.slnsCount);
        }
        public void setAnswer(long answer){
            lAnswer.setText("Answer: "+answer+" combinations");
        }
        public void addSln(String sln){
            txtSlns.append(sln+"\n");
        }
}
